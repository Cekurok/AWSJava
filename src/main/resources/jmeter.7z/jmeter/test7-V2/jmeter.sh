#! /bin/sh
# This file is the part of JMeter_stress_test_cconfig project.
# Copyright (C) 2015, Maxim Markov <maxim.markov@eldorado.ru>.
# Copyright (C) 2015 Eldorado LLC.
# This program may be or may not be distributed under the terms of the agreement with Eldorado LLC.

. ./jmeter.conf # Читаем настройки, созданные при инициализации теста

INPUT=`pwd` # Местоположение файлов дянных и конфигурации

/opt/jmeter/bin/jmeter.sh -Jthreads=$USERS -JdurationTime=$DURATION -JinputDataFolder=$INPUT -Jrampup=$RAMPUP -Jserver=$TARGET -Jport=$HTTPPORT \
-JsecurePort=$HTTPSPORT $@

exit