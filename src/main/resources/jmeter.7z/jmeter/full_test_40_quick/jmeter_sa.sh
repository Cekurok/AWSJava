#! /bin/sh
# This file is the part of JMeter_stress_test_cconfig project.
# Copyright (C) 2015, Maxim Markov <maxim.markov@eldorado.ru>.
# Copyright (C) 2015 Eldorado LLC.
# This program may be or may not be distributed under the terms of the agreement with Eldorado LLC.

INPUT="./" # Местоположение файлов дянных и конфигурации

/opt/apache-jmeter/bin/jmeter.sh -Jthreads=1 -JdurationTime=100 -JinputDataFolder=$INPUT -JoutputDataFolder=$INPUT -Jrampup=1 -Jserver=stage.eldorado.ru -Jport=80 \
-JsecurePort=443 -t ${INPUT}FullTestPlan.jmx

exit